<?php
/**
*
* @package phpBB Extension - tas2580 privacyprotection
* @copyright (c) 2018 tas2580 (https://tas2580.net)
* English translation Update @ Solidjeuh <https://www.froddelpower.be>
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
if (!defined('IN_PHPBB'))
{
	exit;
}
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}
// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ‚ ‘ ’ « » „ “ ” …
//
$lang = array_merge($lang, array(
	'DOWNLOAD_MY_DATA'				=> 'Télécharger mes données personnelles',
	'DOWNLOAD_MY_DATA_EXPLAIN'		=> 'Cliquez ici pour télécharger vos données personnelles (fichier CSV).',
	'DOWNLOAD_MY_POSTS_EXPLAIN'		=> 'Cliquez ici pour télécharger vos messages (fichier CSV).',
	'DOWNLOAD_BTN'					=> 'Télécharger',
	'NEED_ACCEPT_PRIVACY'			=> 'Vous devez d’abord lire et accepter la déclaration de confidentialité.',
	'PRIVACY_ACCEPTED'				=> 'Déclaration de politique de confidentialité lue et acceptée',
	'PRIVACY_ACCEPTED_EXPLAIN'		=> 'En cochant ce champ, je confirme que j’ai lu et accepté la <a href="%s">Déclaration de confidentialité</a>.',
	'PRIVACY_LAST_ACCEPTED'			=> 'Date de la dernière acceptation de la politique de confidentialité',
	'REVOKE_PRIVACY'				=> 'Revoquer',
	'REVOKE_PRIVACY_CONFIRM'		=> 'Confirmez la révoquation',
	'REVOKE_PRIVACY_SUCCESS'		=> 'Révoquation confirmée',
));
