<?php
/**
*
* @package phpBB Extension - tas2580 privacyprotection
* @copyright (c) 2018 tas2580 (https://tas2580.net)
* English translation Update @ Solidjeuh <https://www.froddelpower.be>
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
if (!defined('IN_PHPBB'))
{
	exit;
}
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}
// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ‚ ‘ ’ « » „ “ ” …
//
$lang = array_merge($lang, array(
	'ACP_PRIVACY_SETTINGS'						=> 'Politique de confidentialité - Réglages',
	'ACP_PRIVACY_URL'							=> 'URL de votre déclaration de confidentialité',
	'ACP_PRIVACY_URL_EXPLAIN'					=> 'Veuillez insérer un lien valide vers votre déclaration de confidentialité. Cela remplacera le lien vers la politique de confidentialité d’origine.',
	'ACP_REJECT_URL'							=> 'URL de refus',
	'ACP_REJECT_URL_EXPLAIN'					=> 'Si une URL est spécifiée ici‚ le message de mise à jour émettra un bouton supplémentaire pour désapprouver la politique de confidentialité qui pointe vers l’URL fournie ici. Utiliser <code>{SID}</code> pour représenter user\'s session ID.',
	'ACP_REJECT_GROUP'							=> 'Déplacer vers le groupe',
	'ACP_REJECT_GROUP_EXPLAIN'					=> 'Sélectionnez un groupe auquel seront ajoutés tous les utilisateurs qui n’ont pas accepté la politique de confidentialité.',
	'ACP_NO_REJECT_GROUP'						=> ' - Ne pas déplacer le membre -',
	'ACP_MOVE_GROUP'						    => 'Déplacer de l’ancien groupe',
	'ACP_MOVE_GROUP_EXPLAIN'				    => 'Activer pour déplacer tous les membres du groupe précédemment sélectionné vers le groupe nouvellement sélectionné.',
	'ACP_REG_ACCEPT_PRIVACY'				    => 'Politique de confidentialité lors de l’inscription',
	'ACP_REG_ACCEPT_PRIVACY_EXPLAIN'		    => 'Les utilisateurs doivent-ils accepter la politique de confidentialité lors de l’inscription?',
	'ACP_REG_ACCEPT_MAIL'					    => 'Autoriser les emails de masse lors de l’inscription',
	'ACP_REG_ACCEPT_MAIL_EXPLAIN'			    => 'Les utilisateurs doivent-ils accepter de recevoir des e-mails en masse lors de l’inscription?',
	'ACP_IP_SETTINGS'						    => 'Addresses IP',
	'ACP_ANONYMIZE_IP'							=> 'Anonymiser les adresses IP',
	'ACP_ANONYMIZE_IP_EXPLAIN'					=> 'Choisissez si les adresses IP doivent être anonymisées et si oui quelle méthode utiliser.',
	'ANONYMIZE_IP_NONE'							=> 'Ne pas anonymiser',
	'ANONYMIZE_IP_FULL'							=> 'Anonymiser complètement',
	'ANONYMIZE_IP_HASH'							=> 'Utiliser le hachage',
	'ANONYMIZE_IP_LAST'							=> 'Anonymiser la dernière partie',
	'ACP_ANONYMIZE_IP_TIME'					    => 'Anonymiser automatiquement',
	'ACP_ANONYMIZE_IP_TIME_EXPLAIN'			    => 'Choisissez après combien de temps les adresses seront anonymisées automatiquement et complètement',
	'WEEKS'									    => 'Semaines',
	'MONTHS'								    => 'Mois',
	'YEARS'									    => 'Années',
	'ACP_FOOTERLINK'							=> 'Ajouter le lien au pied de page',
	'ACP_FOOTERLINK_EXPLAIN'					=> 'Si activé un lien vers votre déclaration de confidentialité sera affiché dans le pied de page.',
	'ACP_DATA_DOWNLOAD_OPTIONS'					=> 'Télécharger les données',
	'ACP_POST_FORMAT'							=> 'Messages',
	'ACP_POST_FORMAT_EXPLAIN'					=> 'Définir les données incluses lors du téléchargement des messages.',
	'INCLUDE_TEXT'								=> 'Texte et meta-data',
	'ONLY_META'									=> 'Uniquement les meta-data',
	'ACP_POST_READ'								=> 'Messages visibles uniquement',
	'ACP_POST_READ_EXPLAIN'						=> 'Le téléchargement des messages doit-il être limité à ceux auxquels un utilisateur a accès en lecture ?',
	'ONLY_READ'									=> 'Restreindre aux messages avec accès en lecture',
	'ACP_POST_UNAPPROVED'						=> 'Messages en attente d’approbation',
	'ACP_POST_UNAPPROVED_EXPLAIN'				=> 'Les messages en attente d’approbation doivent-ils être inclus dans le téléchargement ?',
	'ACP_POST_DELETED'							=> 'Messages supprimés',
	'ACP_POST_DELETED_EXPLAIN'					=> 'Les messages supprimés doivent-ils être inclus dans le téléchargement ?',
	'ACP_PRIVACYPROTECTION_PRIVACY_EXPLAIN'		=> 'Ici vous pouvez entrer votre propre déclaration de politique de confidentialité, remplaçant celle prédéfinie le fichier de langue. Vous pouvez utiliser le HTML. Utilisez <code>{SITE_NAME}</code> pour le nom et <code>{SITE_URL}</code> pour l’URL du forum. Laissez le champ vide pour utiliser l’énoncé de politique de confidentialité tel que défini dans le fichier de langue.',
	'PRIVACY_URL_WARNING'						=> 'Vous avez spécifié <a href="%1$s">%1$s</a> comme URL de la déclaration de confidentialité. La déclaration de politique de confidentialité ci-dessus ne s’affichera que si vous supprimez cette URL dans les paramètres.',
	'ACP_PRIVACY_OPTIONS'						=> 'Options de confidentialité',
	'UPDATE_PRIVACY'							=> 'La politique de confidentialité a été mise à jour',
	'UPDATE_PRIVACY_EXPLAIN'					=> 'Effectuez cette action après la mise à jour de la politique de confidentialité. Tous les utilisateurs devront accepter la nouvelle politique de confidentialité.',
	'PRIVACY_POLICE_UPDATED'					=> 'La politique de confidentialité a été définie à la date actuelle. Tous les utilisateurs doivent dabord confirmer à nouveau leur acceptation afin de continuer à utiliser le forum.',
	'ACP_DELETE_IP'						        => 'Anonymiser tous les IP stockées.',
	'ACP_DELETE_IP_EXPLAIN'						=> 'Exécutez cette option pour rendre anonymes toutes les adresses IP stockées dans phpBB. <br> <strong> Attention cela ne peut pas être annulé ! </strong>',
	'IP_DELETE_SUCCESS'							=> 'Toutes les adresses IP ont été anonymisées.',
	'PRIVACY_LAST_ACCPEPT'						=> 'Politique de confidentialité acceptée',
	'LAST_ACCPEPT'								=> 'Dernière acceptation',
	'ACP_SUBMIT'								=> 'Enregistrer les paramètres',
	'ACP_SAVED'									=> 'Paramètres sauvegardés.',
	'USER_LIST_ACEPTED'							=> 'Accepté',
	'USER_LIST_NOT_ACEPTED'						=> 'Non accepté',
	'USER_LIST_NOT_ACEPTED_ONLINE'				=> 'Non Accepté mais s’est connecté',
	'USER_ADMIN_REVOKE_PRIVACY'					=> 'Révoquer la confidentialité',
));
